﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace Purchase_Order_Processing_System.Entities
{
    public class Supplier
    {
        [Key]
        [Column(TypeName = "varchar(4)")]
        public string SuplNo { get; set; }

        [Required]
        [Column(TypeName = "varchar(15)")]
        public string SuplName { get; set; }

        [Column(TypeName = "varchar(40)")]
        public string SuplAddr { get; set; }
    }
}