﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace Purchase_Order_Processing_System.Entities
{
    public class Purchase
    {
        [Key]
        [Column(TypeName = "varchar(4)")]
        public string PoNo { get; set; }

        public DateTime PoDate { get; set; }

        [ForeignKey("Item")]
        [Column(TypeName = "varchar(4)")]
        public string ItCode { get; set; }

        public int Qty { get; set; }

        [ForeignKey("Supplier")]
        [Column(TypeName = "varchar(4)")]
        public string SuplNo { get; set; }

        [JsonIgnore]
        public virtual Item? Item { get; set; }
        [JsonIgnore]
        public virtual Supplier? Supplier { get; set; }
    }
}
