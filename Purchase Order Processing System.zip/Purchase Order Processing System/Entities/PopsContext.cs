﻿using Microsoft.EntityFrameworkCore;

namespace Purchase_Order_Processing_System.Entities
{
    public class PopsContext:DbContext
    {
        private IConfiguration _configuration;

        public PopsContext(IConfiguration configuration)
        {
            _configuration = configuration;
        }


       
        public DbSet<Item> Items { get; set; }
        public DbSet<Purchase> Purchases { get; set; }
        public DbSet<Supplier> Suppliers{ get; set; }
       
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
           
            optionsBuilder.UseSqlServer(_configuration.GetConnectionString("PopsConnection"));
        }
    }
}


