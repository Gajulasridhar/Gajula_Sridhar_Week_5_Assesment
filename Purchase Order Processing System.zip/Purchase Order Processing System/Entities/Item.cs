﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace Purchase_Order_Processing_System.Entities
{
    public class Item
    {
        [Key]
        [Column(TypeName = "varchar(4)")]
        public string ItCode { get; set; }

       
        [Column(TypeName = "varchar(15)")]
        public string? ItDesc { get; set; }

        [Column(TypeName = "int")]
        public int? ItRate { get; set; }
    }
}
