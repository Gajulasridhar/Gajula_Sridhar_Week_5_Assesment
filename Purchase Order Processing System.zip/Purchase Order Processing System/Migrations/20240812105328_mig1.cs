﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Purchase_Order_Processing_System.Migrations
{
    /// <inheritdoc />
    public partial class mig1 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Items",
                columns: table => new
                {
                    ItCode = table.Column<string>(type: "varchar(4)", nullable: false),
                    ItDesc = table.Column<string>(type: "varchar(15)", nullable: false),
                    ItRate = table.Column<decimal>(type: "money", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Items", x => x.ItCode);
                });

            migrationBuilder.CreateTable(
                name: "Suppliers",
                columns: table => new
                {
                    SuplNo = table.Column<string>(type: "varchar(4)", nullable: false),
                    SuplName = table.Column<string>(type: "varchar(15)", nullable: false),
                    SuplAddr = table.Column<string>(type: "varchar(40)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Suppliers", x => x.SuplNo);
                });

            migrationBuilder.CreateTable(
                name: "Purchases",
                columns: table => new
                {
                    PoNo = table.Column<string>(type: "varchar(4)", nullable: false),
                    PoDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    ItCode = table.Column<string>(type: "varchar(4)", nullable: false),
                    Qty = table.Column<int>(type: "int", nullable: false),
                    SuplNo = table.Column<string>(type: "varchar(4)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Purchases", x => x.PoNo);
                    table.ForeignKey(
                        name: "FK_Purchases_Items_ItCode",
                        column: x => x.ItCode,
                        principalTable: "Items",
                        principalColumn: "ItCode",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Purchases_Suppliers_SuplNo",
                        column: x => x.SuplNo,
                        principalTable: "Suppliers",
                        principalColumn: "SuplNo",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Purchases_ItCode",
                table: "Purchases",
                column: "ItCode");

            migrationBuilder.CreateIndex(
                name: "IX_Purchases_SuplNo",
                table: "Purchases",
                column: "SuplNo");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Purchases");

            migrationBuilder.DropTable(
                name: "Items");

            migrationBuilder.DropTable(
                name: "Suppliers");
        }
    }
}
