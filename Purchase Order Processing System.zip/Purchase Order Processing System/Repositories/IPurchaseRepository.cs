﻿using Purchase_Order_Processing_System.Entities;

namespace Purchase_Order_Processing_System.Repositories
{
    public interface IPurchaseRepository
    {
        Task<IEnumerable<Purchase>> GetAllAsync();
        Task<Purchase> GetByIdAsync(string poNo);
        Task AddAsync(Purchase poMaster);
        Task UpdateAsync(Purchase poMaster);
        Task DeleteAsync(string poNo);
    }
}
