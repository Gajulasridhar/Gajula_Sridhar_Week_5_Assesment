﻿using Microsoft.EntityFrameworkCore;
using Purchase_Order_Processing_System.Entities;

namespace Purchase_Order_Processing_System.Repositories
{
    public class SupplierRepository : ISupplierRepository
    {
        private readonly PopsContext _context;

        public SupplierRepository(PopsContext context)
        {
            _context = context;
        }
        public async Task Add(Supplier supplier)
        {
            await _context.Suppliers.AddAsync(supplier);
            await _context.SaveChangesAsync();

        }

        public async Task Delete(string suplNo)
        {
            var product = await _context.Suppliers.FindAsync(suplNo);
            _context.Suppliers.Remove(product);
            await _context.SaveChangesAsync();

        }

        public async Task<IEnumerable<Supplier>> GetAll()
        {
            return await _context.Suppliers.ToListAsync();
        }

        public async Task<Supplier> GetById(string suplNo)
        {
            return await _context.Suppliers.FindAsync(suplNo);
        }

        public async Task Update(Supplier supplier)
        {
            _context.Suppliers.Update(supplier);
            await _context.SaveChangesAsync();

        }
    }
}
