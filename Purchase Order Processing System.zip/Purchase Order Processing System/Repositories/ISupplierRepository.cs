﻿using Purchase_Order_Processing_System.Entities;

namespace Purchase_Order_Processing_System.Repositories
{
    public interface ISupplierRepository
    {
        Task<IEnumerable<Supplier>> GetAll();
        Task<Supplier> GetById(string suplNo);
        Task Add(Supplier supplier);
        Task Update(Supplier supplier);
        Task Delete(string suplNo);
    }
}
