﻿using Purchase_Order_Processing_System.Entities;

namespace Purchase_Order_Processing_System.Repositories
{
    public interface IITemRepository
    {
        Task<IEnumerable<Item>> GetAll();
        Task<Item> GetById(string itCode);
        Task Add(Item item);
        Task Update(Item item);
        Task Delete(string itCode);
    }
}
