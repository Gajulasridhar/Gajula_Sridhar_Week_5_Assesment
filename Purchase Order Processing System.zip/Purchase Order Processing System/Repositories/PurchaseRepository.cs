﻿using Microsoft.EntityFrameworkCore;
using Purchase_Order_Processing_System.Entities;
using System.Reflection.Emit;

namespace Purchase_Order_Processing_System.Repositories
{
    public class PurchaseRepository : IPurchaseRepository
    {
        private readonly PopsContext _context;

        public PurchaseRepository(PopsContext context)
        {
            _context = context;
        }
        public async Task AddAsync(Purchase poMaster)
        {
            await _context.Purchases.AddAsync(poMaster);
            await _context.SaveChangesAsync();

        }

        public  async Task DeleteAsync(string poNo)
        {
            var item = await _context.Purchases.FindAsync(poNo);
            _context.Purchases.Remove(item);
            await _context.SaveChangesAsync();

        }

        public async Task<IEnumerable<Purchase>> GetAllAsync()
        {
            return await _context.Purchases.ToListAsync();

        }

        public async Task<Purchase> GetByIdAsync(string poNo)
        {
            return await _context.Purchases.FindAsync(poNo);

        }

        public async Task UpdateAsync(Purchase poMaster)
        {
            _context.Purchases.Update(poMaster);
            await _context.SaveChangesAsync();

        }
    }
}
