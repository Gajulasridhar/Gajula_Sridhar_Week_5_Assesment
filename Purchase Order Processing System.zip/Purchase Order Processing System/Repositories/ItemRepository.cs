﻿using Microsoft.EntityFrameworkCore;
using Purchase_Order_Processing_System.Entities;

namespace Purchase_Order_Processing_System.Repositories
{
    public class ItemRepository : IITemRepository
    {
        private readonly PopsContext _context;

        public ItemRepository(PopsContext context)
        {
            _context = context;
        }
        public async Task Add(Item item)
        {
            await _context.Items.AddAsync(item);
            await _context.SaveChangesAsync();
        }

        public async Task Delete(string itCode)
        {
            var item = await _context.Items.FindAsync(itCode);
            _context.Items.Remove(item);
            await _context.SaveChangesAsync();
        }

        public async Task<IEnumerable<Item>> GetAll()
        {
            return await _context.Items.ToListAsync();
        }

        public async Task<Item> GetById(string itCode)
        {
            return await _context.Items.FindAsync(itCode);
        }

        public async Task Update(Item item)
        {
            _context.Items.Update(item);
            await _context.SaveChangesAsync();

        }
    }
}
