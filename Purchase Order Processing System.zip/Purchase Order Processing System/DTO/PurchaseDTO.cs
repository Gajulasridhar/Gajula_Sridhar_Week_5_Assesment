﻿namespace Purchase_Order_Processing_System.DTO
{
    public class PurchaseDTO
    {
        public string PoNo { get; set; }
        public string ItCode { get; set; }

        public int Qty { get; set; }

        public string SuplNo { get; set; }
    }
}
