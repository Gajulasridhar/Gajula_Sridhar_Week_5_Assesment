﻿using Microsoft.AspNetCore.Mvc;
using Purchase_Order_Processing_System.Entities;
using Purchase_Order_Processing_System.Repositories;
using System.Threading.Tasks;

namespace Purchase_Order_Processing_System.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SupplierController : ControllerBase
    {
        private readonly ISupplierRepository _supplierRepository;

        public SupplierController(ISupplierRepository supplierRepository)
        {
            _supplierRepository = supplierRepository;
        }

        // GET: api/Supplier/GetSuppliers
        [HttpGet("GetSuppliers")]
        public async Task<IActionResult> GetAll()
        {
            var suppliers = await _supplierRepository.GetAll();
            return Ok(suppliers);
        }

        // GET: api/Supplier/GetSupplier/{id}
        [HttpGet("GetSupplier/{id}")]
        public async Task<IActionResult> Get([FromRoute] string id)
        {
            var supplier = await _supplierRepository.GetById(id);
            if (supplier != null)
                return Ok(supplier);
            else
                return NotFound("Invalid Id");
        }

        // POST: api/Supplier/AddSupplier
        [HttpPost("AddSupplier")]
        public async Task<IActionResult> Add([FromBody] Supplier supplier)
        {
            if (supplier == null)
                return BadRequest("Supplier object is null");

            await _supplierRepository.Add(supplier);
            return CreatedAtAction(nameof(Get), new { id = supplier.SuplNo }, supplier);
        }

        // PUT: api/Supplier/EditSupplier
        [HttpPut("EditSupplier")]
        public async Task<IActionResult> Edit([FromBody] Supplier supplier)
        {
            if (supplier == null)
                return BadRequest("Supplier object is null");

            await _supplierRepository.Update(supplier);
            return NoContent();
        }

        // DELETE: api/Supplier/DeleteSupplier?id={id}
        [HttpDelete("DeleteSupplier")]
        public async Task<IActionResult> Delete([FromQuery] string id)
        {
            await _supplierRepository.Delete(id);
            return NoContent(); // Empty Response
        }
    }
}
