﻿using Microsoft.AspNetCore.Mvc;
using Purchase_Order_Processing_System.Entities;
using Purchase_Order_Processing_System.Repositories;
using System.Threading.Tasks;

namespace Purchase_Order_Processing_System.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PurchaseController : ControllerBase
    {
        private readonly IPurchaseRepository _purchaseRepository;

        public PurchaseController(IPurchaseRepository purchaseRepository)
        {
            _purchaseRepository = purchaseRepository;
        }

        // GET: api/Purchase/GetPurchases
        [HttpGet("GetPurchases")]
        public async Task<IActionResult> GetAll()
        {
            var purchases = await _purchaseRepository.GetAllAsync();
            return Ok(purchases);
        }

        // GET: api/Purchase/GetPurchases/{id}
        [HttpGet("GetPurchases/{id}")]
        public async Task<IActionResult> Get([FromRoute] string id)
        {
            var purchase = await _purchaseRepository.GetByIdAsync(id);
            if (purchase != null)
                return Ok(purchase);
            else
                return NotFound("Invalid Id");
        }

        // POST: api/Purchase/AddPurchase
        [HttpPost("AddPurchase")]
        public async Task<IActionResult> Add([FromBody] Purchase purchase)
        {
            if (purchase == null)
                return BadRequest("Purchase object is null");

            await _purchaseRepository.AddAsync(purchase);
            return CreatedAtAction(nameof(Get), new { id = purchase.PoNo }, purchase);
        }

        // PUT: api/Purchase/EditPurchase
        [HttpPut("EditPurchase")]
        public async Task<IActionResult> Edit([FromBody] Purchase purchase)
        {
            if (purchase == null)
                return BadRequest("Purchase object is null");

            await _purchaseRepository.UpdateAsync(purchase);
            return NoContent();
        }

        // DELETE: api/Purchase/DeletePurchase?id={id}
        [HttpDelete("DeletePurchase")]
        public async Task<IActionResult> Delete([FromQuery] string id)
        {
            await _purchaseRepository.DeleteAsync(id);
            return NoContent(); // Empty Response
        }
    }
}
