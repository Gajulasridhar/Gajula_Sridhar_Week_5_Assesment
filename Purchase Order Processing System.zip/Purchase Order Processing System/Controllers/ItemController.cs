﻿using Microsoft.AspNetCore.Mvc;
using Purchase_Order_Processing_System.Entities;
using Purchase_Order_Processing_System.Repositories;
using System.Threading.Tasks;

namespace Purchase_Order_Processing_System.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ItemController : ControllerBase
    {
        private readonly IITemRepository _itemRepository;

        public ItemController(IITemRepository itemRepository)
        {
            _itemRepository = itemRepository;
        }

        // GET: api/Item/GetItems
        [HttpGet("GetItems")]
        public async Task<IActionResult> GetAll()
        {
            var items = await _itemRepository.GetAll();
            return Ok(items);
        }

        // GET: api/Item/GetItem/{id}
        [HttpGet("GetItem/{id}")]
        public async Task<IActionResult> Get([FromRoute] string id)
        {
            var item = await _itemRepository.GetById(id);
            if (item != null)
                return Ok(item);
            else
                return NotFound("Invalid Id");
        }

        // POST: api/Item/AddItem
        [HttpPost("AddItem")]
        public async Task<IActionResult> Add([FromBody] Item item)
        {
            if (item == null)
                return BadRequest("Item object is null");

            await _itemRepository.Add(item);
            return CreatedAtAction(nameof(Get), new { id = item.ItCode }, item);
        }

        // PUT: api/Item/EditItem
        [HttpPut("EditItem")]
        public async Task<IActionResult> Edit([FromBody] Item item)
        {
            if (item == null)
                return BadRequest("Item object is null");

            await _itemRepository.Update(item);
            return NoContent();
        }

        // DELETE: api/Item/DeleteItem?id={id}
        [HttpDelete("DeleteItem")]
        public async Task<IActionResult> Delete([FromQuery] string id)
        {
            await _itemRepository.Delete(id);
            return NoContent(); // Empty Response
        }
    }
}
